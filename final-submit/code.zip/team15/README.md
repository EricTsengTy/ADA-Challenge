## How to build
```
make magic
```

## How to run
```
./magic < ${input_file} > ${output_file} 2> /dev/null
```